<?php

    header("Content-type: application/json");

    $sitename = "http://localhost/MyServer/";
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $database = "server_db";
    $tbl_user = "users";

?>