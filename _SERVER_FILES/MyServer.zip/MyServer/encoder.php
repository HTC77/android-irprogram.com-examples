<?php

    $result = "";

    if( isset( $_POST['data'] ) && ( !empty( $_POST['data'] ) ) )
    {
        $result = "result of encoding <b>".$_POST['data'] .
                    "</b>:<br />" . base64_encode( $_POST['data'] );
    }

?>
<html>
    <head>
        <title>base64 maker</title>
    </head>

    <body>
        <form action="" method="post">
            <input type="text" id="data" name="data" />
            <input type="submit" value="generate" />
        </form> <br />

        <?php echo $result; ?>
    </body>
</html>
