<?php

    require_once("include.php");

    $error['state'] = "";

    if( isset( $_POST['uname'] ) && ( !empty( $_POST['uname'] ) ) &&
        isset( $_POST['upass'] ) && ( !empty( $_POST['upass'] ) ) &&
        isset( $_POST['umail'] ) && ( !empty( $_POST['umail'] ) ) )
    {
        $temp_uname = $_POST['uname'];
        $temp_upass = base64_encode($_POST['upass']);
        $temp_umail = $_POST['umail'];

        $connect = @mysqli_connect($hostname , $username , $password , $database );
        if( $connect )
        {
            $un = @mysqli_real_escape_string( $connect , $temp_uname );
            $up = @mysqli_real_escape_string( $connect , $temp_upass );
            $um = @mysqli_real_escape_string( $connect , $temp_umail );

            $query = "INSERT INTO ".$tbl_user."(uname, upass, email) ".
                                "VALUES('".$un."','".$up."','".$um."')";

            @mysqli_query( $connect , $query );

            if( @mysqli_affected_rows( $connect ) > 0 )
            {
                $error['state'] = "done";
            }
            else
            {
                $error['state'] = "failed";
            }
        }
        else
        {
            $error['state'] = "inaccessible";
        }
    }

    die( json_encode($error) );

?>