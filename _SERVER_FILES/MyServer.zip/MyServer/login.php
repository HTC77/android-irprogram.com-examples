<?php

    require_once("include.php");

    $error['state'] = "";

    if( isset( $_POST['uname'] ) && ( !empty( $_POST['uname'] ) ) &&
        isset( $_POST['upass'] ) && ( !empty( $_POST['upass'] ) ) )
    {
        $temp_uname =  $_POST['uname'] ;
        $temp_upass = base64_encode( $_POST['upass'] );

        $connect = @mysqli_connect($hostname , $username , $password , $database );
        if( $connect )
        {
            $un = @mysqli_real_escape_string( $connect , $temp_uname );
            $up = @mysqli_real_escape_string( $connect , $temp_upass );

            $query = "SELECT id FROM ".$tbl_user." WHERE uname='".$un."' AND upass='".$up."'";

            $result = @mysqli_query( $connect , $query );

            $rows = @mysqli_num_rows( $result );

            if( $rows > 0 )
            {
                $error['state'] = "ok";
            }
            else
            {
                $temp_upass = $_POST['upass'];
                $up = @mysqli_real_escape_string( $connect , $temp_upass );
                $query = "SELECT id FROM ".$tbl_user." WHERE uname='".$un."' AND upass='".$up."'";
                $result = @mysqli_query( $connect , $query );
                $rows = @mysqli_num_rows( $result );
                if( $rows > 0 )
                {
                    $error['state'] = "ok";
                }else{
                    $error['state'] = "unknown";
                }
            }
        }
        else
        {
            $error['state'] = "inaccessible";
        }
    }

    die( json_encode($error) );

?>